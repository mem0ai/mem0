import os

USER_ID = os.getenv("USER", "default_user")
DEFAULT_APP_ID = "openmemory"